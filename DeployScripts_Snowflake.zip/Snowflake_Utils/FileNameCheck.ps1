<#
.SYNOPSIS
To check file name format <CHG|INC><7-digits>_YYYYMMDD_<3-digits>
 
#>

[CmdletBinding()]
param(
[Parameter(Mandatory = $false)][String]$folderpath = "Z_Releases"    
)
begin{
	write-host "Source Branch:" $Env:BUILD_SOURCEBRANCHNAME
	}
process {

	try {   
		     [regex]$reg1 = "CHG\d{7}_\d{4}\d{2}\d{2}_\d{3}.XML"
        	 [regex]$reg2 = "INC\d{7}_\d{4}\d{2}\d{2}_\d{3}.XML"
			 $invalidfilelist=@()
	    	 $builddirectory = $Env:BUILD_SOURCESDIRECTORY			
			 $Path = "$builddirectory\$folderpath"	    	
			 $directoryList = Get-ChildItem -Path $Path -Recurse -Directory           
			if($directoryList -ne $null){
			    ForEach($directory in $directoryList) {
						$files = Get-ChildItem -Path $directory.FullName -Recurse -exclude *.md, .gitignore | Where-Object { ! $_.PSIsContainer }
				       	
						if($files -ne $null){
				 		ForEach ($file in $files) {
							try {
											
								$extractedDate=$file.Name.Split("_")[1]
								[datetime]::ParseExact($extractedDate,'yyyyMMdd',$null).ToString('yyyyMMdd')
							}
							catch {
								$invalidfilelist += ,$file
								write-host " invalid date format detected " $file.Name
							}
							if((($reg1.match($file.Name)).Success -eq $True -or ($reg2.match($file.Name)).Success -eq $True)) {
								continue

							}
							else {
								$invalidfilelist += ,$file
                                 continue
							}
						 
					    }  
						    if($invalidfilelist -ne $null)	{
						 
							write-host "Please check file name or date format as per naming convention <CHG|INC><7-digits>_YYYYMMDD_<3-digits.XML>."
							$invalidfilelist.Name
							Exit 1
						 }
						 else{
							 write-host "File names are validated"
						 }
						  
						   }  
						   else {
							   Write-Host "this directory" $directory "doesnot contain any files"
						   }
				        }  
				
				} 

			else {
				Write-Host "folders are empty"			
		    }	
		} 
		
        catch {
           Write-Host $_.Exception.Message -ForegroundColor Red
           Exit 1
        } 
 }

end {
    Write-host "*****Task Complete: File name checked****"
}