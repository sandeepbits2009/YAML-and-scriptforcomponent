[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]$PATtoken,
    [Parameter(Mandatory = $false)]$FolderPath = "build\Z_Releases",
    [Parameter(Mandatory = $false)]$SourceFolder, 
    [Parameter(Mandatory = $false)]$DestinationFolder
	)
  begin{
    write-host "Source Branch:" $Env:BUILD_SOURCEBRANCHNAME
}

process {
    
  try {
    $defaultbuilddirectory = $Env:AGENT_BUILDDIRECTORY 
    cd $defaultbuilddirectory\$FolderPath
    $filecontent = Get-Content .\history.txt
    $fileformat = $filecontent.split('/').split('::')
    $builddirectory = $Env:AGENT_BUILDDIRECTORY
    $outputlist = @()
    foreach ($file in $fileformat) {if ($file -match ".xml") {$outputlist += "$file"}}
    $Path = "$builddirectory\$FolderPath\$SourceFolder"
    $filelist = @()
    foreach ($file in $outputlist) {
       $repofilelist = Get-ChildItem -path $Path -Recurse -Include *.xml | where-object {$_.Name -eq $file}
       $filelist += $repofilelist
       }
    $filelist = $filelist | select -Unique 
    if ($filelist -ne $null) {
       Write-Host "File to be Archived:" $filelist
      }

#############Copy XML Files from RELEASES to RELEASES_ARCHIVE folder##################
    foreach ($file in $filelist) {
       $source = "$file"
       $fileformat = Split-Path -Path "$file" -Leaf -Resolve
       $source = "$builddirectory\$FolderPath\$SourceFolder\$fileformat"
       $destination = "$builddirectory\$FolderPath\$DestinationFolder\$fileformat"
      
       Copy-Item -Path $source -Destination $destination -Recurse
##############Remove the Files in the source Branch##################
       Get-ChildItem -Path $Path  | Where-Object {$_.Name -eq $fileformat} | Remove-Item -Verbose
      }

  }
  catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Exit 1
 }
}