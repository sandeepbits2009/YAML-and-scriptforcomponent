﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]$org_name = "KC-DataAnalytics",
    [Parameter(Mandatory = $false)]$project_name = "DevOps-COE",
    [Parameter(Mandatory = $true)]$PAT_Token
  	)

begin
{
    write-host "****Task Started*****"
}

process
{
    $token = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("PAT:$PAT_Token"))
    $env:AZURE_DEVOPS_EXT_PAT = "$PAT_Token"
    $headers = @{
        'Authorization' = "Basic $token"
    }
    $pullrequestID = $env:SYSTEM_PULLREQUEST_PULLREQUESTID
    $z = az repos pr show --id "$pullrequestID" --organization "https://dev.azure.com/$org_name/" | ConvertFrom-Json
    $repoId = $z.repository.id
    $commitId = $z.lastMergeCommit.commitId
    $uri = "https://dev.azure.com/$org_name/$project_name/_apis/git/repositories/$repoId/commits/$commitId/changes?api-version=6.0"
    $r = Invoke-WebRequest -Method Get -Uri $uri -Headers $headers -ContentType 'application/json' 
    $s = $r.Content | ConvertFrom-Json
    $description = ""
    foreach ($a in $s.changes)
    {
        $b=$a.item.path
        Write-Host "Added/Changed files: $b"
        $description = $description + "   " + $b
    }
    $description = "Changed or added files are: " + $description 
    az repos pr update --id "$pullrequestID" --title $b -d $description --organization "https://dev.azure.com/$org_name/" --auto-complete "true" 
    
}

end
{
    Write-host "*****Task Complete*****"
}