<#
Script used to push the downloaded ddl files to the respective git repository . It uses non user account to push the changes

.Parameter OrgName
Valid Orgname in azure devops

.Parameter ProjectName
Valid projectname in azure devops


.Parameter DatabaseName
Please mention the Database in SnowFlake

.Parameter BranchName
Mention the branchname to push the changes

.Parameter Email
Mail id used to authenticate repo and push the changes

.Parameter PATToken
Used to authenticate git repo .Please note that the pat token should be created with the same non user account ID.
#>
param(
   
    [Parameter(Mandatory = $true)][string]$orgName,
    [Parameter(Mandatory = $true)][string]$projectName,
    [Parameter(Mandatory = $true)][string]$databaseName,
    [Parameter(Mandatory = $false)][string[]]$schemaList = "",
    [Parameter(Mandatory = $true)][string]$Branchname,
    [Parameter(Mandatory = $true)][string]$email,
    [Parameter(Mandatory = $true)][string]$PATToken
)

git config --global user.email $email
git config --global user.name "IA IT Centre Bangalore GDTC Engineering - DevOps Azure Devops"
git config --global advice.detachedHead false
$url = "https://$orgName@dev.azure.com/$orgName/$projectName/_git/$databaseName"

$token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATToken)"))

git -c http.extraHeader="Authorization: Basic $token" clone $url -v

push-location $env:Build_ArtifactStagingDirectory\$databaseName
git checkout master
git reset --hard origin/$Branchname
git pull origin $Branchname
if($schemaList -ne $null)
{
    $schemaList = $schemaList.split(",")
    foreach ($schema in $schemaList)
    {
        write-host "Schema selected for the update: $schema"
        $source = "$env:System_defaultworkingdirectory\$databaseName\$schema"
        $destination = "$env:Build_ArtifactStagingDirectory\$databaseName\$schema"
        Robocopy.exe  $source $destination /E
        if ($LASTEXITCODE -le 4) {
            write-host "exit code for the copy attempt $LASTEXITCODE " 
            write-host "Succesfully copied the file from $source to $destination"
            write-host "Succesfully copied the schema $schema files"
        }
        else {
            throw "Copying files to the repo failed. Please see the robocopy logs for more details"
            exit 1
        }
 }
}
else
{
        $source = "$env:System_defaultworkingdirectory\$databaseName"
        $destination = "$env:Build_ArtifactStagingDirectory\$databaseName"
        Robocopy.exe  $source $destination /E
        if ($LASTEXITCODE -le 4) {
            write-host "exit code for the copy attempt $LASTEXITCODE " 
            write-host "Succesfully copied the file from $source to $destination"
        }
        else {
            throw "Copying files to the repo failed. Please see the robocopy logs for more details"
            exit 1
        }
}
git add *
git commit -am "[skip ci] Updating the ddl files to the repo"
git -c http.extraHeader="Authorization: Basic $token" push -f -v
Pop-Location

