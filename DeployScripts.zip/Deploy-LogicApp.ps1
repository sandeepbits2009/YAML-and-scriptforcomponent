<#
.Synopsis
Script helps to deploy the required API connections . User needs to fill out the JSON file for each environment and the same file
will be considered as input for this script . 

Note- Script dont have authentication mechanism currently to connect with azure services . Please use the script in Azure PowerShell task in pipeline for automatic authentication

.PARAMETER JsonPath
Input Json file path required for the deployment and its mandatory

.EXAMPLE

./Deploy-LogicApp.ps1 -JsonPath C:\temp\Parameter_Prod.json

#>

param (
     [Parameter(Mandatory = $true)][String]$JsonPath
)

try
{
    
    $ReadJson =  Get-Content -Path $JsonPath -Raw | ConvertFrom-Json
    foreach ($connection in $ReadJson.LogicApp)
    {
       $API                 = $connection.API
       $ResourceLocation    = $connection.ResourceLocation
       $ResourceGroupname   = $connection.ResourceGroupName
       $ConnectionName      = $connection.ConnectionName
       $SubscriptionName    = $connection.SubscriptionName
       $CreateConnection    = $connection.CreateConnection

       if($createConnection)
       {
          $SubscriptionId = Get-AzSubscription -SubscriptionName $SubscriptionName
          $connection     = New-AzResource -Properties @{"api" = @{"id" = "subscriptions/" + $SubscriptionId.Id + "/providers/Microsoft.Web/locations/" + $ResourceLocation + "/managedApis/" + $API}; "displayName" = $ConnectionName; } -ResourceName $ConnectionName -ResourceType "Microsoft.Web/connections" -ResourceGroupName $ResourceGroupName -Location $ResourceLocation -Force
         }
        
    }
}
catch
{
    Write-host "Failed to create the API . Please refer the failure message below" -Foregroundcolor red
    Write-host "Failure reason : $_ " -Foregroundcolor red
    exit 1
}
