<#
.SYNOPSIS
Download the checkmarx scan report from the server after succesfull scanning process . 
Inorder to run this task/script , checkmarx scan step should happen prior to this script/task execution 

Steps performed -->
    1. Generates a bearer token from checkmarx for api authentication purpose
    2. Download the current pipeline build logs and extract it
    3. Look for the Checkmarx scan log file and read the unique scanID which gets generated for each succesful scan
    4. Register/Generate the scan report in checkmarx using POST call
    5. Download the report as PDF format in artifactsstaging directory 

Use Publish Build Artifact to publish the report as artifacts for each pipeline

 
.PARAMETER CheckmarxserverIp
Hostname or IP of the checkmarx server to connect
 
.PARAMETER CheckmarxserverUsername
Username to connect with checkmarx server to generate the bearer token
 
.PARAMETER CheckmarxserverUserPassword
Password to connect with checkmarx server to generate the bearer token
     
.PARAMETER Checkmarxserverclientsecret
Currently the checkmarx server client secret is static and same value needs to be used always
Please refer the documentation if you have any doubts on this
URL ---> https://checkmarx.atlassian.net/wiki/spaces/KC/pages/1187774721/Using+the+CxSAST+REST+API+v8.6.0+and+up

.PARAMETER PATToken 
PAT Token to connect with azure devops 

.PARAMETER Downloadpath (Optional)
Location where the report will get downloaded . By default it downloads to artifactsstaging directory and using publish artifact task , it can be directly published
otherwise it needs to be copied again explicitly to artifact location before it gets published . Recommendation is not to change the value

.PARAMETER LogFileName (Optional)
Logfile name where scanID will be available . Filename is nothing but the task name for Checkmarx scan analysis . Change the logfile name only if the task name of checkmarx
gets changed. Currently no changes required


#>
param (
             [Parameter(Mandatory = $false)][String]$CheckmarxserverIp = "webscan.kccweb.net",
             [Parameter(Mandatory = $false)][String]$CheckmarxserverUsername,
             [Parameter(Mandatory = $false)][String]$CheckmarxserverPassword, 
             [Parameter(Mandatory = $false)][String]$CheckmarxserverClientSecret = "014DF517-39D1-4453-B7B3-9930C563627C",
			 [Parameter(Mandatory = $false)][String]$DownloadPath = "$env:Build_ArtifactStagingDirectory\CheckmarxReport.pdf",
             [Parameter(Mandatory = $false)][String]$PATToken ,
             [Parameter(Mandatory = $false)][String]$LogFileName
        )
try
        {		
				$ErrorActionPreference = "Stop"
                $count = 0
				
                #checkmarx login
                $connecturl = "https://$checkmarxserverIp/cxrestapi/auth/identity/connect/token"
                 $body = @{
                                "username" = "$CheckmarxserverUsername"
                                "password" = "$CheckmarxserverPassword"
                                "grant_type" = "password"
                                "scope"      = "sast_rest_api"
                                "client_id"  = "resource_owner_client"
                                "client_secret" = "$CheckmarxserverClientSecret"
                            }
                Write-Host "Generating the bearer token for the checkmarx login"
				[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12

   			  $request = Invoke-RestMethod -Uri $connecturl -Method POST -ContentType "application/x-www-form-urlencoded" -Headers $header -Body $body -ErrorAction Stop
                $token = $request.access_token
                write-host "Token generated for login checkmarx succesfully"
       

                ###############region to download the buildpipeline logs
                $tokens = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PATToken)"))
                $header = @{authorization = "Basic $tokens"}
                
                do
                {
                    #Cleaning up the build folder if present
					if(Test-path -path "$env:Build_SourcesDirectory\$env:Build_BuildID*")
					{
						Write-host "Cleaning up the build folders before fresh download"
						Remove-item -Path "$env:Build_SourcesDirectory\$env:Build_BuildID*" -Recurse -Force
					}
					$url = "$env:System_TeamFoundationServerUri" + "/$env:System_TeamProject/_apis/build/builds/$env:Build_BuildID/logs?api-version=6.0&%24format=zip"
                    write-host "Url to download the build logs $url"
                    $output = Invoke-RestMethod -Uri $url -Method Get -ContentType "application/zip" -Headers $header -OutFile "$env:Build_SourcesDirectory\$env:Build_BuildID.zip" -ErrorAction Stop
					write-host "Expanding the zip files started"
                    expand-archive "$env:Build_SourcesDirectory\$env:Build_BuildID.zip" -destination $env:Build_SourcesDirectory\$env:Build_BuildID
                    write-host "Zip files got extracted succesfully to read the log files"
                    $fileName = Get-ChildItem -path "$env:Build_SourcesDirectory\$env:Build_BuildID" -Filter "*$LogfileName*" -Recurse
                    Write-Host "Logfile name from the build logs - $filename"
                    if($fileName -eq $null)
                    {
                        write-host "Attempt $count"
                        write-host "Log file for static code analysis not present in build logs . Trying to download after 10seconds.."
                        if($count -eq 4)
                        {
                            throw "Failed to download the build logs after multiple attempts"
                            exit 1
                        }
                        start-sleep 10
						$count++
                    }
                    else {
                        write-host "Fetched the log file to read the scan ID . Exiting the loop"
                        break
                    }
                }while ($count -lt 5)
				write-host "Reading the ScanID from the log file ---- $filename"
                $scanID = (select-string -Path $fileName -Pattern "(?:scanId=)(.*?)(?:&)").Matches |  % {$_.groups[1].Value} 
                write-host "Scan ID generated from the checkmarx server for the current scan is $scanID"
      
                #checkmarx register report
                 $header = @{authorization = "Bearer $Token"}
               
                 $body = @{
                                "reportType" = "PDF"
                                "scanId" = $scanID
                            } | ConvertTo-Json
                $url = "https://$CheckmarxserverIp/cxrestapi/reports/sastScan"
                $registerreport = (Invoke-RestMethod -Uri $url -Method POST -ContentType "application/json" -Headers $header -Body $body -ErrorAction Stop).links.report.uri
                write-host "reporturl from checkmax generated is $registerreport"
                
				#waiting for the report to be available in checkmarx after registering it
                start-sleep -seconds 10

                #download the report
                $url = "https://$CheckmarxserverIp/cxrestapi" + "$registerreport"
                $header = @{authorization = "Bearer $Token"}
                $downloadreport = Invoke-RestMethod -Uri $url -Method GET -ContentType "application/pdf" -Headers $header -OutFile $DownloadPath -ErrorAction Stop
                Write-Host "Succesfully downloaded the scan report to the following location $Downloadpath "
       
                #Clean up  the build log folders
                Remove-item -Path "$env:Build_SourcesDirectory\$env:Build_BuildID*" -Recurse -ErrorAction SilentlyContinue
                write-host "Succesfully removed the build logs folder from the agent server"
    }
catch
        {
                throw $_
				exit 1
				write-host "Failed to  download the scan report from checkmarx due to the below failure reason" -ForegroundColor Red
                write-host $_.Exception.Message -ForegroundColor Red
				#Write-Host "##vso[task.logissue type=error]Failed to generate the checkmarx report"
		

        }


