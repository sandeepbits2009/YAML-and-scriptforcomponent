<#
.SYNOPSIS
Copy Files between ADFS Path.

.PARAMETER BearerToken
The target Environment (QA, PROD) Databricks Bearer token to authenticate to your workspace (see User Settings in Databricks WebUI), to which the DBFS files are exported
 
.PARAMETER Region
The Target Environment (QA, PROD) Azure Region - must match the URL of your Databricks workspace, example northeurope

.PARAMETER LocalPath
Localpath in which all the files are existing to get imported and Exported to the Databricks DBFS path

.PARAMETER ConfigPath
Path to the config file which will have both the library type and library names in the format below. Comma seperated with LibraryType:LibraryName

pyp:Azure,pyp:azure-datalake-store
.EXAMPLE
C:\PS> 	.\Copy-DataBricksDBFSFiles.ps1 -BearerToken "$BearerToken" -Region "southcentralus" -LocalPath "$LocalPath" -ConfigFile ".\config.txt" -Verbose
 
#>

[CmdletBinding()]
param(
   
    [Parameter(Mandatory = $true)]$BearerToken,
    [Parameter(Mandatory = $true)]$Region,
    [Parameter(Mandatory = $true)]$LocalPath,
    [Parameter(Mandatory = $true)]$ConfigFile
)

begin {
    write-host `BearerToken 	:  $BearerToken
    write-host `Region      	:  $Region
    write-host `LocalPath       :  $LocalPath
    write-host `ConfigFile      :  $ConfigFile
}

process {
    Write-host "*****Task Open: Copying  to the DBS*****"
   
    $UpdateScriptPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
   . ([System.IO.Path]::Combine($UpdateScriptPath, ".\Use-LogHelper.ps1"))

    Write-Host "*****Task 1: Installing PowerShell Module: azure.databricks.cicd.tools*****"

    if (Get-Module -ListAvailable -Name azure.databricks.cicd.tools) {
    Write-Host "azure.databricks.cicd.tools Module already exists"
    } 
    else {
    Write-Host "Module does not exist, Installing ..."
    Install-Module -Name azure.databricks.cicd.tools -Verbose -Scope CurrentUser -Force
    }   
    
    Write-Host "*****Task 2: Importing PowerShell Module: azure.databricks.cicd.tools*****"

    Import-Module -Name azure.databricks.cicd.tools -Verbose
	
    try {
        Write-Host "*****Task 3: Copy DataBricks DBFS files from soruce to target Environment *****"
        $libraryfile = Get-Content -path $ConfigFile
        $libarray = $libraryfile -split ","
        #Write-Host "List of Liraries to install: " $libarray 
  
        foreach ($lib in $libarray) {
            $libtype, $libname = $lib -split ':', 2 
            $libtype = $libtype.Trim()
            $libname = $libname.Trim() 
                    
            write-host "Library Type: " $libtype  ", Library Name: " $libname

            if ($libname -match "dbfs:") {

                #Test the file path of target dbfs, if file exisit, it will skip the copy task

                $filePath = Split-Path -Path $libname
                $DBFSPath = $filePath.Replace("dbfs:","").Replace('\','/')
                $fileName = $libname.Split('/')[-1]
                Connect-Databricks -BearerToken $BearerToken -Region $Region -Verbose
                $testPath = @()
                try{
                $testPath += Get-DatabricksDBFSFolder -BearerToken $BearerToken -Region $Region -Path $DBFSPath | where {($_.is_dir -eq $false) -and ($_.file_size -igt 1)} -Verbose -ErrorAction SilentlyContinue
                }
                catch {$null}
                foreach ($Path in $testPath){
                if ($Path -match $fileName){$FileSize = $Path.file_size}
                }
                if ($testPath -match $fileName){
                Write-Host "The file $fileName is present with Size: $([math]::round($FileSize /1mb, 2)) MB in the target Path: $DBFSPath,`nSkipping the DBFS file import process ..." -ForegroundColor Green 
                }
                else{

                Write-Host "The file $fileName not exist in the target path : $DBFSPath, hence importing the file to the path" -ForegroundColor Green
                
                if (Test-Path $LocalPath)
                {
                #Export the files to DBFS file share in Present Environment

                Connect-Databricks -BearerToken $BearerToken -Region $Region -Verbose
                Add-DatabricksDBFSFile -BearerToken $BearerToken -Region $Region -LocalRootFolder $LocalPath -FilePattern "$fileName" -TargetLocation $DBFSPath -Verbose -ErrorAction Stop
               }
               else {Write-Host "Error: No jar files present in the $localPath, add the jar file to continue.."}
            }
            $DBFSfiles = @()
            $DBFSfiles += "$libname"               
        }
    }
        Write-Host "The following jar files are added to DBFS path: `n" $DBFSfiles
    }
    catch {
        Write-Log "Exception occured: $($_.Exception.Message) `n Stack Trace: `n $($_.ScriptStackTrace)" -Severity Error 
        throw $_
    }
    finally
{
	# Mandatory to restore the log variables, once it is been set in the starting of the script
	Restore-LogVariables
}

}

end {
    Write-host "*****Task Complete: Imported the Databricks DBFS files to the Present Environment*****"
} 