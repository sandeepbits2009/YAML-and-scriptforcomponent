#! /bin/bash
set -e
NotebookName=$1
#install papermill if its not already present
pip3 install papermill
python3 -m ipykernel install --user --name py36test
echo "Invoking notebook using papermill"
papermill ./"$NotebookName" "output.ipynb" -k "py36test"
# will fail for error codes > 0
RetValue=$?
if [ $RetValue -eq 0 ]; then
    echo "Succesfully executed the $ScriptName Notebook"
else
    echo "Notebook execution failed "
	exit $RetValue
fi
cat "output.ipynb"
