﻿<#
.SYNOPSIS
Get the Pipeline ID for the given ML Service Pipeline Endpoint

.PARAMETER ResourceGroupName
Name of the resource group

.PARAMETER MLWorkspaceName
Name of the ML Workspace Name

.PARAMETER PipelineEndpointName
Name of the Pipeline Endpoint

.PARAMETER ApplicationId (Optional)
Application ID of the Application registered in Azure Active Directory
 
.PARAMETER SecurePassword (Optional)
Secure Password string of the Application
     
.PARAMETER TenantId (Optional)
Tenant ID of the Application registered in Azure Active Directory

.EXAMPLES

This script gets the Pipeline ID for the given ML Service Pipeline Endpoint

Please download the whole repository of deploy scripts as it has some dependency with other ps scripts

Manual Usage - 
If script needs to be triggered manually for testing and other purpose, ApplicationID,TenantID and Securepassword are required for successful manual run

C:\PS> Get-MLServicePipelineEndpoint.ps1 -ResourceGroupName $ResourceGroupName -ApplicationId $ApplicationId -SecurePassword $SecurePassword -TenantId $TenantId -MLWorkspaceName $MLWorkspaceName -PipelineEndpointName $PipelineEndpointName

CI Usage (Azure CLI tasks)

If the script is invoked via Azure powershell task  ApplicationID,TenantID and Securepassword are not required since the task itself
integrates with Azure resources using automated service principal 

C:\PS> Get-MLServicePipelineEndpoint.ps1 -ResourceGroupName $ResourceGroupName -MLWorkspaceName $MLWorkspaceName -PipelineEndpointName $PipelineEndpointName

C

#>

[CmdletBinding()]
param(
     [Parameter(Mandatory = $true)]$ResourceGroupName,
     [Parameter(Mandatory = $true)]$MLWorkspaceName,  
     [Parameter(Mandatory = $true)]$PipelineEndpointName,
     [Parameter(Mandatory = $false)]$ApplicationId, 
     [Parameter(Mandatory = $false)]$SecurePassword, 
     [Parameter(Mandatory = $false)]$TenantId
	)

begin
{
    write-host `MLWorkspaceName      :  $MLWorkspaceName
    write-host `ResourceGroupName    :  $ResourceGroupName
    write-host `PipelineEndpointName :  $PipelineEndpointName
}

process
{   
    write-host `ApplicationId :  $ApplicationId
    write-host `TenantId      :  $TenantId
    Write-host "*****Task Open: Fetching the Pipeline IDs for the ML Service Pipeline Endpoints*****"
	
	try {
		    
		    if($env:AGENT_ID)
			{
				Write-host "Script is getting executed on azure ps task . Hence Login parameters are not required to connect azure resources"
			}
			else
			{
				Write-host "*****Task 1: Az-Login using Service principal*****"
				az login --service-principal --username $ApplicationId --password $SecurePassword --tenant  $TenantId
			}
            
            az extension add -n azure-cli-ml
            
            $currentdir = Get-Location
            $Outpufilename = "PipelineOutput.json"
            Write-host "*****Task 2: Creating the file PipelineOutput.json*****"
            New-Item -Path $currentdir -Name $Outpufilename -ItemType "file" -Force

            $outputfile = Join-path -Path $currentdir -ChildPath $Outpufilename

            if(Test-path -Path $outputfile) {
                Write-host "*****Task 3: PipelineOutput.json file exists*****"
                 
                Write-host "*****Task 4: Fetching the list of ML Service Pipeline Endpoints in the ML workspace*****"
                $pipelines = az ml pipeline list -g $ResourceGroupName -w $MLWorkspaceName -f $outputfile --verbose
                $frommlworkspace = Get-Content $outputfile | Out-String | ConvertFrom-Json
                 
                $frommlworkspace = $frommlworkspace | Select-object -Property Name, Id
                
                $ExistingPipelineEndpoints = $PipelineEndpointName.split(",")
                 
                write-host "------------------------------------------------------------------------"
                Write-host "Pipeline Endpoints Count             : " $ExistingPipelineEndpoints.Count 
                Write-host "Pipeline Endpoints to check          : " $ExistingPipelineEndpoints
                write-host "------------------------------------------------------------------------"
                write-host "ML workspace Pipeline Endpoints Count: " $frommlworkspace.Count 
                Write-host "ML workspace Pipeline Endpoints      : " $frommlworkspace
                write-host "------------------------------------------------------------------------"

                $pipelineid = ""
                foreach ($pipeline in $ExistingPipelineEndpoints) {
                    if ($frommlworkspace.Name -match $pipeline) {
                        $res =  $frommlworkspace | Where {$_.Name -eq $pipeline} | Select-Object -Property $_.Id
                        $id = $res.id
                    }
                    $pipelineid += $id + ","
                  }
                Write-host "Pipeline Endpoind ID for: " $pipeline " is " $pipelineid             
                }
                 
                $pipelineid = $pipelineid.TrimEnd(',')
                [array]::Reverse($pipelineid)      
                write-host "Pipeline Endpoint ID :" $pipelineid                 
                Write-Host "##vso[task.setvariable variable=PipelineEndpointID]$pipelineid"
          }
	catch {
		 Write-Host $_.Exception.Message -ForegroundColor Red
		 Exit 1
	}
    if (!($env:AGENT_ID))
	{
		az logout
		Write-Host "Disconnected from the active azure connection succesfully"
	}
}

end
{
    Write-host "*****Task Complete:Fetched the Pipeline ID/Endpoints for the ML Service Pipeline Endpoint*****"
}