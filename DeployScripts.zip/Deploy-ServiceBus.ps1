<#
.Synopsis
Script helps to deploy the service bus topics and required subscription for each topic . User needs to fill out the JSON file for each environment and the same file
will be considered as input for this script . 

Note- Script dont have authentication mechanism currently to connect with azure services . Please use the script in Azure CLI task in pipeline for automatic authentication

.PARAMETER JsonPath
Input Json file path required for the deployment and its mandatory

.EXAMPLE

./Deploy-ServiceBus.ps1 -JsonPath C:\temp\Parameter_QA.json

#>
param (
     [Parameter(Mandatory = $true)][String]$JsonPath
)
try
{
    
    $ReadJson =  Get-Content -Path $JsonPath -Raw | ConvertFrom-Json
    foreach ($topic in $ReadJson.ServiceBus)
    {
       $TopicName = $topic.TopicName
       $ResourceGroupname = $topic.ResourceGroupName
       $Topicnamespace =  $topic.NameSpacename
       $SubscriptionName = $topic.SubscriptionName
       $EnableStatus = $topic.Status
       $Enablesession = $topic.Enablesession
       $MaximumSize = $topic.MaximumSize
       $EnablePartioning = $topic.EnablePartioning
       $EnableOrdering = $topic.EnableOrdering
       $Enableexpress = $topic.Enableexpress
       $Enableduplicatedetection = $topic.Enableduplicatedetection
       $Enablebatchedoperation = $topic.Enablebatchedoperation
       $MaximumDeliveryCount = $topic.MaximumDeliveryCount
       $LockDuration   = $topic.LockDuration
       $DefaultMessagetoLive = $topic.DefaultMessagetoLive
       $AutoDeleteonidle = $topic.AutoDeleteonidle
        
        $Arguments = "az servicebus topic create --name {0} --namespace-name {1} --resource-group {2} --max-size {3} --enable-batched-operations {4} --enable-duplicate-detection {5} --enable-express  {6} --enable-ordering {7} --enable-partitioning {8} --status {9}"
        $Arguments = ($Arguments -f $TopicName, $Topicnamespace, $ResourceGroupname , $MaximumSize ,  $Enablebatchedoperation , $Enableduplicatedetection , $Enableexpress , $EnableOrdering ,  $EnablePartioning , $EnableStatus)  
        Write-Host "Constructed arguements are $Arguments"
        Write-Host "Deploying service bus topic $TopicName started ..."
        Invoke-expression $Arguments
        Write-Host "Azure service bus topic $TopicName created succesfully" -Foregroundcolor Green

        $Arguments = "az servicebus topic subscription create --name {0} --namespace-name {1} --resource-group {2} --topic-name {3} --enable-session {4} --max-delivery-count {5} --lock-duration {6} --default-message-time-to-live {7} --auto-delete-on-idle {8}"
        $Arguments = ($Arguments -f  $SubscriptionName ,$Topicnamespace ,  $ResourceGroupname , $TopicName , $Enablesession , $MaximumDeliveryCount , $LockDuration , $DefaultMessagetoLive , $AutoDeleteonidle )  
        Write-Host "Constructed arguements are $Arguments"
        write-host "Creating subscription for the topic $TopicName"
        Invoke-expression $Arguments
        Write-host "Succesfully created subscription $SubscriptionName for the topic $TopicName" -Foregroundcolor Green
    }
}
catch
{
    Write-host "Failed to create the eventhub endpoints. Please refer the failure message below" -Foregroundcolor red
    Write-host "Failure reason : $_ " -Foregroundcolor red
    exit 1
}