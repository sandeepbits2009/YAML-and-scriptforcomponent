<#
.SYNOPSIS
Activates the Triggers in the DataFactory
 
.PARAMETER ResourceGroupName
Resource group Name in Azure
 
.PARAMETER ApplicationId (Optional)
Application ID of the Application registered in Azure Active Directory
 
.PARAMETER SecurePassword (Optional)
Secure Password string of the Application
     
.PARAMETER TenantId (Optional)
Tenant ID of the Application registered in Azure Active Directory

.PARAMETER DataFactoryName (Optional)
Name of the DataFactory Name

.EXAMPLE
This example activates the trigger in the Azure Data Factory. DataFactory name is optional input . If its not passed , Value will be fetched from the resourcegroup.


Manual Usage - 

If script needs to be triggered manually for testing and other purpose, ApplicationID,TenantID and Securepassword are required for successful manual run

C:\PS> Activate-DFTrigger.ps1 -ResourceGroupName $ResourceGroupName -ApplicationId $ApplicationId -SecurePassword $SecurePassword -TenantId $TenantId

CI/CD Usage (Azure Powershell task)

If the script is invoked via Azure powershell task  ApplicationID,TenantID and Securepassword are not required since the task itself
integrates with Azure resources using automated service principals

C:\PS> Activate-DFTrigger.ps1 -ResourceGroupName $ResourceGroupName 



#>
[CmdletBinding()]
param(
   
    [Parameter(Mandatory = $true)]$ResourceGroupName, 
    [Parameter(Mandatory = $false)]$ApplicationId, 
    [Parameter(Mandatory = $false)]$SecurePassword, 
    [Parameter(Mandatory = $false)]$TenantId,
    [Parameter(Mandatory = $false)]$ConfigFile,
    $DataFactoryName
)

begin {
    write-host `ResourceGroupName :  $ResourceGroupName

    function check {
        $global:listoffailedTriggers = @{}
        foreach ($Trigger in $Triggers) {
            if ( $Configfileflag -ieq 'true') {
                write-host 'Triggers are from ADF'
                $TriggerName = $Trigger.Name
                $TriggerStatus = $Trigger.RuntimeState
            }
            else {
                write-host 'Triggers are from Configfile'
                $TriggerName = $Trigger
            }
		
            Write-host `Trigger   : $TriggerName, $TriggerStatus
            $result = Start-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue

            if (($?) -and ($result)) {
                write-host "Successfully started the trigger!!"
            }
            Else {
                $status = $null
                $countAttempt = 1
                while ($countAttempt -le 10) { 
                    #           
                    $result = Start-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue
                    $status = Get-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -Name $TriggerName -ErrorAction SilentlyContinue
                    Write-Host "Trying to restart the $Trigger, Checking the status .."
                    if ($($status.RuntimeState) -eq "Started")
                    { break; }
                    else {
                        $countAttempt = $countAttempt + 1 
                        Write-Host "Trying to restart the $Trigger and count is $countAttempt"
                        if (($listoffailedTriggers.ContainsKey($TriggerName)) -eq $false) {
                            $listoffailedTriggers.Add($TriggerName, $RuntimeState);
                
                        }
                    }
                } 
        
		
            }
        
        }
    }
}

process {
    Write-host "*****Task Open: Activating the Triggers for the Datafactory*****"
    if ((Get-Module -ListAvailable -Name AzureRM.DataFactoryV2) -and (Get-Module -ListAvailable -Name AzureRM.Resources)) {
        Write-Host "AzureRM.DataFactoryV2 and AzureRM.Resources Module already exists"
    } 
    else {
        Write-Host "Module does not exist, Installing ..."
        Install-Module -Name AzureRM.DataFactoryV2 -Verbose -Scope CurrentUser -Force
        Install-Module -Name AzureRM.Resources -Verbose -Scope CurrentUser -Force
    }   
    if ($env:AGENT_ID) {		
        Write-host "Script is getting executed on azure ps task . Hence Login parameters are not required to connect azure resources"
    }
    else {
	
        $SecurePassword = $SecurePassword | ConvertTo-SecureString -AsPlainText -Force
        $credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ApplicationId, $SecurePassword
		
        try {
            Write-host "*****Connect-AzureRmAccount*****"
            Connect-AzureRmAccount -ServicePrincipal -Credential $credential -TenantId $TenantId
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
        }
		
        try {
            Write-Host "*****Login-AzureRmAccount*****"
            Login-AzureRmAccount -ServicePrincipal -Credential $credential -TenantId $tenantId
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
        }
    }

    $ResourceGroup = Get-AzureRmResourceGroup -Name $ResourceGroupName
    write-host "Resource Group: " $ResourceGroup
	
    try {
        Write-host "*****Task 1: Getting the Datafactory name from the Resource Group*****"
        if (!$DataFactoryName) {
            $Datafactory = Get-AzureRmDataFactoryV2 -ResourceGroupName $ResourceGroupName
            $DataFactoryName = $DataFactory.DataFactoryName
        }
        Write-Host "DataFactoryName: " $DataFactoryName
        Write-Host "*****Task 2: Getting the Trigger Names and RunTimeState from the Datafactory*****"
        $Configfileflag = 'true'
        if ($ConfigFile) {
            $Configfileflag = 'false'
            write-host "Using ConfigFile as input for starting the Triggers"
            $triggerfile = Get-Content -path $ConfigFile
            $Triggers = $triggerfile -split ","
            check $Triggers
            if($global:listoffailedTriggers.keys){
				$finalList = ($listoffailedTriggers.keys|Out-String)
				Write-Host "##vso[task.logissue type=warning]Failed to activate the below triggers $finalList "
				Write-Host "##vso[task.logissue type=warning]Please remove the unused/unlinked triggers from dev environment and publish the changes"
			}
			else
			{
				write-host "Succesfully activated  all the triggers"
			}
        }
        else {
            $Triggers = Get-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName | select-object -Property Name, RuntimeState
            check $Triggers
            if($global:listoffailedTriggers.keys){
				$finalList = ($listoffailedTriggers.keys|Out-String)
				Write-Host "##vso[task.logissue type=warning]Failed to activate the below triggers $finalList "
				Write-Host "##vso[task.logissue type=warning]Please remove the unused/unlinked triggers from dev environment and publish the changes"
			}
			else
			{
				write-host "Succesfully activated  all the triggers"
			}
        }
        if (!$Triggers) {
            write-host "No Triggers available or failed to get the Triggers for the $DatafactoryName !" -ForegroundColor Red
            write-host $_.Exception.Message -ForegroundColor Red
            write-host $_.Exception.ItemName -ForegroundColor Red
            Exit 1
        }
	
        Write-host "Total Number of Triggers:" $Triggers.count 
        Write-Host "*****Task 3: Starting the Triggers in the Datafactory*****"
    }
    catch {
        write-host "Failed to get the DatafactoryName for the $ResourceGroupName !" -ForegroundColor Red
        write-host $_.Exception.Message -ForegroundColor Red
        write-host $_.Exception.ItemName -ForegroundColor Red
        Exit 1
    }
    Write-Host "*****Task 4: Disconnect-AzureRmAccount*****"
    if (!($env:AGENT_ID)) {
        Disconnect-AzureRmAccount
        Write-Host "Disconnected from the active azure connection succesfully"
    }
}

end {
    Write-host "*****Task Complete: Activated the Triggers for the Datafactory*****"
}