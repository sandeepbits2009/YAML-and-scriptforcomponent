   $ProcessActive = Get-Process -Name "wlrun" -ErrorAction SilentlyContinue
   for ($n=0 ; $n -lt 2 ; $n++ )
   {
   if($ProcessActive -eq $null){
   Write-host "wlrun is not running"
   break
   }
   if($ProcessActive -ne $null){
   Write-Host "wlrun is running"
   Start-Sleep -Seconds 6
   }
   }