﻿<#
.SYNOPSIS
Create a Batch application package record and activate it

.PARAMETER ApplicationName
Application Name in the Azure Batch account
 
.PARAMETER BatchAccountName
Name of the Batch account
     
.PARAMETER PackageFile
The path of the application package in zip format

.PARAMETER ResourceGroupName
Name of the resource group

.PARAMETER ApplicationId(Optional)
Application ID of the Application registered in Azure Active Directory
 
.PARAMETER SecurePassword(Optional)
Secure Password string of the Application
     
.PARAMETER TenantId(Optional)
Tenant ID of the Application registered in Azure Active Directory

.PARAMETER PoolId
Pool ID of the Batch Application

.PARAMETER NodeId
Node ID in the Batch Application

.EXAMPLE
This script creates a Batch Application package record in the Azure Batch account and also removes all the previous installed packages and retains only last 2 packages in the Batch Account



CI Usage:

ApplicationID,TenantID and Securepassword are not required since the task itself
integrates with Azure resources using automated service principal 

C:\PS> Create-BatchApplication.ps1 -ApplicationName $ApplicationName -BatchAccountName $BatchAccountName -PackageFile $PackageFile -ResourceGroupName $ResourceGroupName -VersionName $VersionName
 
Manual Run Usage:

ApplicationID,TenantID and Securepassword are required for successful manual run

Create-BatchApplication.ps1 -ApplicationName $ApplicationName -BatchAccountName $BatchAccountName -PackageFile $PackageFile -ResourceGroupName $ResourceGroupName -VersionName $VersionName -ApplicationId $ApplicationId -SecurePassword $SecurePassword -TenantId $TenantId

#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$ApplicationName, 
    [Parameter(Mandatory = $true)]$BatchAccountName, 
    [Parameter(Mandatory = $true)]$PackageFile,
	[Parameter(Mandatory = $true)]$ResourceGroupName,
	[Parameter(Mandatory = $false)]$ApplicationId,
	[Parameter(Mandatory = $false)]$SecurePassword,
    [Parameter(Mandatory = $false)]$TenantId,
    [Parameter(Mandatory = $true)]$PoolId,
    [Parameter(Mandatory = $true)]$NodeId
	)

begin
{
    write-host `ApplicationName  :  $ApplicationName
    write-host `BatchAccountName :  $BatchAccountName
    write-host `PackageFile      :  $PackageFile
    write-host `ResourceGroupName:  $ResourceGroupName
    write-host `PoolId           :  $PoolId
    write-host `NodeId           :  $NodeId
}

process
{
    Write-host "*****Task Open: Creating a Batch Application package record in the Azure Batch account*****"
	
	try {
		
		if($env:AGENT_ID)
		{
		    Write-host "Script is getting executed on Azure ps tasks . Hence Login parameters are not required to connect azure resources"
		}
		else
		{
			Write-host "*****Task 2: Az-Login using Service principal*****"
			az login --service-principal --username $ApplicationId --password $SecurePassword --tenant  $TenantId
		}

        $filename = Get-ChildItem -Path $PackageFile -Name
        Write-host $filename
        if(!$filename) {
            write-host "No files available in $filename"
            Exit 1
        }

        $PackageFile = Join-Path -Path $PackageFile -ChildPath $filename
        write-host $PackageFile

        $VersionName = get-item $PackageFile | select-object -expandproperty basename
        Write-host "Version Name: " $VersionName
        $res = az batch application package create --application-name $ApplicationName --name $BatchAccountName --package-file $PackageFile --resource-group $ResourceGroupName --version-name $VersionName
        write-host "Application Creation: "$res

        $AppState = $res | ConvertFrom-Json
        $AppState = $AppState.state
        Write-host "Application Status:" $AppState
        
        if($AppState -ne "Active") {
            Write-host "Application Package not created successfully, Check for error log"
            Exit 1
        }
        else
        {
            Write-host "Application Package created successfully in the Batch Account"
            Write-host "*****Task 3: Az Batch Login in the resource group*****"
            az batch account login --name $BatchAccountName --resource-group $ResourceGroupName 

            Write-host "*****Task 4: Az Batch Application setting with the Default version*****"
            az batch application set --application-name $ApplicationName --name $BatchAccountName --resource-group $ResourceGroupName --default-version $VersionName

           Write-host "*****Task 5: Rebooting the Node in the pool*****"
            az batch node reboot --pool-id $PoolId --node-id $NodeId
            
            Write-host "*****Task 5: Fetching the list of Application Packages in the Batch Account*****"
            $packageList = az batch application package list --application-name $ApplicationName --name $BatchAccountName --resource-group $ResourceGroupName |  convertfrom-json
            $excludedlist = $packageList.name 
            write-host "List of all the packages present as of now:" $excludedlist
            $excludedlist = $packageList.name | sort -Descending | Select-Object -Skip 2
            write-host "Application Packages to be removed:" $excludedlist
            
            foreach($package in $excludedlist) {
                write-host "Deleting the package:" $package
                if($package -eq $VersionName)
                {
                    Write-Host "Latest package hence not deleting it"
                }
                else
                {
                    az batch application package delete --application-name $ApplicationName --name $BatchAccountName --resource-group $ResourceGroupName --version-name $package --yes
                }
            }
        }
      }

	catch {
		 Write-Host $_.Exception.Message -ForegroundColor Red
		 Exit 1
	}
    if (!($env:AGENT_ID))
	{
		az logout
		Write-Host "Disconnected from the active azure connection succesfully"
	}
}

end
{
    Write-host "*****Task Complete:Creating a Batch Application package record in the Azure Batch account*****"
}