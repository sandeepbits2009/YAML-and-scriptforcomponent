<#
.SYNOPSIS
Renames the Archive File Name to get in the Build Number Format
OldFileName: BuildId.zip (697.zip)
NewFileName: 2019.11.8.4.zip
#>

$dottedDate = (Get-Date).ToString("yyyy.M.d")
[String]$myrev = $Env:BUILD_BUILDNUMBER

$result = $myrev.Substring($myrev.LastIndexOf('.') + 1)
$newzipfileName = $dottedDate + "." + $result + ".zip"
write-host "Zip File Name: " $zipfileName
write-host "Build Id: " $(Build.BuildId)
$oldzipfileName = $(Build.BuildId)
Rename-Item "$(Build.ArtifactStagingDirectory)\$oldzipfileName.zip" "$newzipfileName"