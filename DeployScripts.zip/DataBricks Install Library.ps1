﻿<#
.SYNOPSIS
Installs a library to a Databricks cluster.
 
.DESCRIPTION
Attempts install of library. 
 
.PARAMETER BearerToken
Your Databricks Bearer token to authenticate to your workspace (see User Settings in Databricks WebUI)
 
.PARAMETER Region
Azure Region - must match the URL of your Databricks workspace, example northeurope
 
.PARAMETER LibraryType
egg, jar, pypi, whl, cran, maven

.PARAMETER ClusterId
The cluster to install the library to.
 
.PARAMETER ConfigFile
Path to the config file which will have both the library type and library names in the format below. Comma seperated with LibraryType:LibraryName
pyp:Azure,pyp:azure-datalake-store
 
.EXAMPLE
C:\PS> DataBricks Install Library.ps1 -BearerToken $BearerToken -Region $Region -ClusterId 'Bob-1234' -ConfigFile $ConfigFile
 
The above example applies a pypi library to a cluster by id 

#>

[CmdletBinding()]
param(
   
    [Parameter(Mandatory = $true)]$BearerToken, 
    [Parameter(Mandatory = $true)]$Region,
    [Parameter(Mandatory = $true)]$ClusterId,
    [Parameter(Mandatory = $true)]$ConfigFile
)

begin {
    write-host `BearerToken 	:  $BearerToken
    write-host `Region      	:  $Region
    write-host `ClusterId   	:  $ClusterId
    write-host `ConfigFile      :  $ConfigFile
}

process {
    $RestartCluster = $false
    $UpdateScriptPath = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
    . ([System.IO.Path]::Combine($UpdateScriptPath, ".\Use-LogHelper.ps1"))
   
    Write-host "*****Task Open: Installing library to the Databricks Cluster*****"
    Write-Host "*****Task 1: Installing PowerShell Module: azure.databricks.cicd.tools*****"

    if (Get-Module -ListAvailable -Name azure.databricks.cicd.tools) {
    Write-Host "azure.databricks.cicd.tools Module already exists"
    } 
    else {
    Write-Host "Module does not exist, Installing ..."
    Install-Module -Name azure.databricks.cicd.tools -Verbose -Scope CurrentUser -Force
    }
        
    Write-Host "*****Task 2: Importing PowerShell Module: azure.databricks.cicd.tools*****"
    Import-Module -Name azure.databricks.cicd.tools -Verbose
	
    $libraryfile = Get-Content -path $ConfigFile
    $libarray = $libraryfile -split ","
    Write-Host "List of Liraries to install: " $libarray 

    [array]$jarfiles = @()
    [array]$AllDBFSpath = @()
    [array]$testPath = @()
    [array]$DBFSjunkjar = @()
    [array]$Libraries = @()
    [array]$fulljarfiles = @()
    [array]$fileExtension = @()
        
    foreach ($lib in $libarray) {
        $libtype, $libname = $lib -split ':', 2
        write-host "Library Type: " $libtype  ", Library Name: " $libname
    }
	
    try {
        # TODO: Use new Logger
        $global:LogToHost = $true
        $global:logPath = "$ENV:AGENT_RELEASEDIRECTORY"
        Set-LogVariables -LogFolderPath "$global:logPath" -LogFileName "DataBricks_Install_lib.log"
	
        Write-Host "For additional logs please find in $global:logPath\DataBricks_Install_lib.log"

        Write-Host "*****Task 3: Getting the Databricks Cluster details*****"
            
        $cluster = Get-DatabricksClusters -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId | Select-Object -Property state
        $clusterstate = $cluster.state
            
        Write-Host "*****Task 4: Starting Databricks Cluster*****"
        if ($clusterstate -notmatch "RUNNING") {
             Write-host "Starting the Databricks Cluster"
              
             Start-DatabricksCluster -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId    
             Start-Sleep -Seconds 30
        }
        Write-Host "*****Task 5: Installing the Library to the Databricks Cluster*****"

        foreach ($lib in $libarray) {
            
            $libtype, $libname = $lib -split ':', 2 
            $libtype = $libtype.Trim()
            $libname = $libname.Trim() 
                    
            write-host "Library Type: " $libtype  ", Library Name: " $libname 
            write-host "Getting the list of libraries present in cluster"
            $Listoflibraries =  Get-DatabricksLibraries -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId
            $Existinglibraries = $Listoflibraries.library.pypi.package
            if($Existinglibraries -ne $NULL)
            {
                   $LibrarynamefromConfig = $lib.Split(":")[1]
                   $Checkavailability =$Existinglibraries.Contains($LibrarynamefromConfig)
                   if($Checkavailability -match "False")
                    { 
                        $libnamesplit = $lib.Split(":")[1]
                        $Librarynamewithoutversion = $libnamesplit.Split("==")[0]
                        [string]$RemoveLibrary = $Existinglibraries -match $Librarynamewithoutversion
                        if($Existinglibraries -match $Librarynamewithoutversion)
                        {                                        
                            Remove-DatabricksLibrary -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId -LibraryType pypi -LibrarySettings $RemoveLibrary -Verbose
                            Add-DatabricksLibrary -BearerToken $BearerToken -ClusterId $ClusterId -LibraryType $libtype -LibrarySettings $libname -Region $Region -Verbose 
                            write-host "Succesfully added the library $libname"
                            $RestartCluster = $true
                        }
                        else
                        {
                            Add-DatabricksLibrary -BearerToken $BearerToken -ClusterId $ClusterId -LibraryType $libtype -LibrarySettings $libname -Region $Region -Verbose 
                            write-host "Succesfully added the library $libname"
  
                        }
                       
                    }
                    else
                    {
                            write-host "Library $Librarynamefromconfig present already . Hence not installing it"
                    }
            }
            else
            {
                Write-Host "Cluster dont have any libraries . Hence installing it"
                Add-DatabricksLibrary -BearerToken $BearerToken -ClusterId $ClusterId -LibraryType $libtype -LibrarySettings $libname -Region $Region -Verbose 
            }
            if ($libname -match "dbfs:") {
    
                #Test the file path of target dbfs, if file exisit, it will skip the copy task

                $DBFSfullName = $libname.Replace("dbfs:", "")
                $filePath = Split-Path -Path $DBFSfullName
                $DBFSPath = $filePath.Replace('\', '/')
                $fileName = $libname.Split('/')[-1]
                $Extension += $libname.Split('.')[-1]
                $jarfiles += $DBFSfullName
                $fulljarfiles += $libname
                $fileExtension = $Extension | Select -Unique
                Connect-Databricks -BearerToken $BearerToken -Region $Region -Verbose
                $testPath = Get-DatabricksDBFSFolder -BearerToken $BearerToken -Region $Region -Path $DBFSPath | where { ($_.is_dir -eq $false) -and ($_.file_size -igt 1) } -Verbose
                $AllDBFSPath += $($testPath.path)
    
                
            }   
        }

        #Remove unnessasary libraries from DBFS path if exist

        if ($AllDBFSpath.Count -ne 0) {

        $AllDBFSpath = $AllDBFSpath | select -Unique

        $DBFSjunkjar = Compare-Object -ReferenceObject ($jarfiles | Select-Object) -DifferenceObject ($AllDBFSpath | Select-Object) -PassThru

        If ($DBFSjunkjar.Count -ne 0) {
            foreach ( $jar in $DBFSjunkjar) {
                Write-Host "Removing $jar from the DBFS path"
                $DBFSJarfile = ( -join ("dbfs:", $jar))
                Remove-DatabricksDBFSItem -BearerToken $BearerToken -Region $Region -Path $DBFSJarfile -Verbose
            }
            Write-Host "uninstalling the $DBFSJarfile file from cluster"
        }
        }
        #Remove libraries from cluster 

        If ($fulljarfiles.Count -ne 0) {
    
        $Libraries = Get-DatabricksLibraries -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId -Verbose
        foreach ($ext in $fileExtension){
            $RmLibraries = Compare-Object -ReferenceObject ($fulljarfiles | Select-Object) -DifferenceObject ($($libraries.library.$ext) | Select-Object) -PassThru
            if ($RmLibraries.count -ne 0) {
                Foreach ($RmLibrary in $RmLibraries) {
                    Write-Host "uninstalling the $RmLibrary file from cluster"
                    Remove-DatabricksLibrary -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId -LibraryType $ext -LibrarySettings $RMLibrary -Verbose
                }
             }
        }     
      }
       #Restart the Cluste
    if($RestartCluster -eq $true)
    {
    write-host "Restarting the cluster after library installation"
    Restart-DatabricksCluster -BearerToken $BearerToken -Region $Region -ClusterId $ClusterId -ErrorAction SilentlyContinue
    }
    }
    
    catch {
        Write-log "Exception occured. $($_.Exception.Message) `n Stack Trace: `n $($_.ScriptStackTrace)" -Severity Error
        throw $_
    }
    finally {
      # Mandatory to restore the log variables, once it is been set in the starting of the script
       Restore-LogVariables
    }
}
end {
    Write-host "*****Task Complete: Installed the library to the Databricks Cluster*****"
}