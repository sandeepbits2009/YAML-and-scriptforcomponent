<#
.SYNOPSIS
SendEmail.ps1 script to send release notes to   ADO group memebers mails  
.ADOGroup paremeter to input ado group name ex DL015142
.Filepath parameter refers a output file generated from releasenotes task ex:'/releasenotes.md'

#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$ADOGroup,
    [Parameter(Mandatory = $true)]$Filepath
   
)

$EmailAddresses = Get-ADGroupMember $ADOGroup -Recursive | Get-ADUser -Properties mail | Select mail
ForEach ($EmailAddress In $EmailAddresses){
  $mailAddresses = $EmailAddress.mail + "," + $mailAddresses 
}
$mailAddresses = $mailAddresses.TrimEnd(',')
$smtpServer = "mailhost.kcc.com"
$attachment = $Filepath

$msg=new-object Net.Mail.MailMessage
$filename=new-object Net.Mail.Attachment($attachment)

$smtp=new-object Net.Mail.SmtpClient($smtpServer)

$msg.From="IABOAP03@kcc.com"
$msg.To.Add($mailAddresses)
$msg.Subject = "Release Notes"
$msg.Body="Please find the attached release notes"
$msg.Attachments.Add($filename)
$smtp.Send($msg)

