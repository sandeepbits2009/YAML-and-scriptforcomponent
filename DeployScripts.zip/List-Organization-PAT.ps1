<#

.PARAMETER organization
Name of Organization
     
.PARAMETER authtoken
JWT access token from the Microsoft identity platform (formerly Azure AD v2.0)
The access token is used as a bearer token to authenticate the user when calling the API.

#>

[CmdletBinding()]
param(
	[Parameter(Mandatory = $true)]$organization, 
	[Parameter(Mandatory = $true)]$authtoken,
    [Parameter(Mandatory = $true)]$adtoken,
    [Parameter(Mandatory = $true)]$subjectDescriptor
)

begin
{
    write-host `organization  :  $organization
    write-host `orgUrl        :  $orgUrl
    write-host `queryString   :  $queryString
}

process
{
    # Define organization base url and API version variables
    $orgUrl = "https://dev.azure.com/$organization"
    $queryString = "api-version=6.1-preview.1"
    Write-host "*****Process Open: Gets a paged list of personal access tokens (PATs) created in this organization*****"
    try {
        $token = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("PAT:$authtoken"))
        $headers = @{
            'Authorization' = "Basic $token"
        }
        $adtoken = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes("PAT:$adtoken"))
        $adheaders = @{
            'Authorization' = "Basic $adtoken"
        }
        Write-Host 'Getting all tokens...'
        $uri = "https://vssps.dev.azure.com/$organization/_apis/tokenAdmin/personalaccesstokens/$subjectDescriptor/?api-version=6.1-preview.1"
        $r = Invoke-WebRequest -Method Get -Uri $uri -Headers $headers -ContentType 'application/json'

        $jsonObj = $r | ConvertFrom-Json
        foreach($obj in $jsonObj.value)
        {
            if ($obj.validTo) {
                Write-Host "Name: " $obj.displayName "validTo: " $obj.validTo
                $displayName = $obj.displayName
                $validTo = $obj.validTo
                $currentDate = Get-Date
                $validTo  = [DateTime]$validTo
                $ts = New-TimeSpan -Start $currentDate -End $validTo
                $daysLeft = $ts.Days
                $lines += "Token: $displayName, $daysLeft :Days Left for Token Expiration"
                Write-Host "Token: $displayName, $daysLeft :Days Left for Token Expiration"
                if ($daysLeft -le "30") {
                    Write-Host 'Update Token Expiration...'
                    $validTo = $validTo.AddDays(90)
                    Write-Host $validTo
                    $uri = "https://vssps.dev.azure.com/$organization/_apis/tokens/pats?api-version=6.1-preview.1"
                    $params = New-Object psobject -property @{
                        'authorizationId' = $obj.authorizationId
                        'validTo' = $validTo
                    } | ConvertTo-Json
                    $update = Invoke-WebRequest -Method PUT -Uri $uri -Headers $adheaders -Body $params -ContentType 'application/json'
                    Write-Host $update
                    $lines += "Token: $displayName, $validTo :AutoExtend with 90 Days"
                    Write-Host "Token: $displayName, $validTo :AutoExtend with 90 Days"
                }
            } else {
                $lines += "Token: $displayName, validTo value not found"
                Write-Host "Token: $displayName, $daysLeft :Days Left for Token Expiration"
            }
        }
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

end
{
    Write-host "*****Process Complete: Happy Devops*****"
    echo "##vso[task.setvariable variable=result;isOutput=true]$lines"
}