<#
Parameter:
$Module_names = Will except parameter like "AzureRM","BitsTransfer"
In Azure DevOps task section in Arguments we can specify the parameter like this -module_name "AzureRM","BitsTransfer"...

What this script do?
First it will search whether specified module is installed or not then if it is not installed then one by one it will install.   
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$Module_names=@()
)

begin {
Write-Host "*****************#Begin Step#*********************"
}

process {
foreach($Module_name in $Module_names)
{
 if (Get-Module -Name "$Module_name" -ListAvailable) {
    Write-Warning -Message "Azure '$Module_name' module is not installed."
 } else {
    Install-Module -Name "$Module_name" -AllowClobber -Scope AllUsers -Force
   }
  }
 }

end {
Write-Host "*****************#End Steps#*********************"
}