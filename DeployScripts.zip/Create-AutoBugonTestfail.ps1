<#
.SYNOPSIS
Creates a bug up on failed test cases.
.EXAMPLE
C:\PS> Create-AutoBugonTestfail.ps1 -PAT "jmgsqripkbqrvbg3g2dvrerxxlwiiflm3c27mbla4gxiazumvy7q" -OrgName "KC-DataAnalytics" -Project 'Devops-COE' -Area "Deliverables" -RunID "1234" -AssignedTo "anusha.paritala@kcc.com"
 
#>



[CmdletBinding()]
param(
   
    [Parameter(Mandatory = $true)]$PAT, 
    [Parameter(Mandatory = $true)]$OrgName,
    [Parameter(Mandatory = $true)]$Project,
    [Parameter(Mandatory = $true)]$Area,
    [Parameter(Mandatory = $true)]$RunID,
    [Parameter(Mandatory = $true)]$AssignedTo
)

begin {

}
process
 {
    $token = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($PAT)"))
    $header = @{authorization = "Basic $token"}
    $workitemType = "Bug"
    $Reason = "Build Failure"
    $tags = "Automation"
    $orgUrl = "https://dev.azure.com/$OrgName"
    $testResultsRunUrl = "$orgUrl/$Project/_apis/test/Runs/$RunID/results?api-version=6.0"
   try {
    $TestSuiteResult = Invoke-RestMethod $testResultsRunUrl -Method Get -ContentType "application/json" -Headers $header
    $TestSuiteScenariosRunResults = $TestSuiteResult.value
   }
   catch {
    write-host "failed while fecthing test runs from  $testResultsRunUrl !" -ForegroundColor Red
    write-host $_.Exception.Message -ForegroundColor Red
    } 
     if ($TestSuiteScenariosRunResults.Count -gt 0)
      {
            Write-Host " $($TestSuiteScenariosRunResults.count) test cases founds" -ForegroundColor Blue
            for ($i = 0; $i -lt $TestSuiteScenariosRunResults.Count; $i++)
             {
                $currentTestCase = $TestSuiteScenariosRunResults[$i]
                 if ($currentTestCase.outcome -ne "Passed") 
                 {                    
                     $WorkItemQueryURL = "$orgUrl/$Project/_apis/wit/wiql?api-version=6.0"
                     $body =@"{
                     "query": "Select [System.Id], [System.Title], [System.State] From WorkItems Where [System.Tags] = 'Automation' AND [System.WorkItemType] = 'Bug'"}"@
                   
                     $WorkItems = Invoke-RestMethod -Uri $WorkItemQueryURL -ContentType "application/json" -Body $body -Headers $header -Method POST

                    ForEach ($ID in $WorkItem.workItems.id)
                    {
                      $WorkItemInfoURL = "$orgUrl/$Project/_apis/wit/workitems/$($ID)?api-version=6.0" 

                      $BugID = Invoke-RestMethod -Uri $WorkItemInfoURL -Method Get -Headers $header

                      $exist = $BugID.fields.'System.Title'.Contains($RunID)
   
                      if($exist)
                      {
                        Write-Host "Bug already created for failed Test run  for $RunID " 
                        break;
                      }
                    }
                    if(-not($exist))
                    {
                    Write-Host "Creating bug for failed test case" -ForegroundColor Red
                    
                    $createBugWorkItemUrl = "$orgUrl/$Project/_apis/wit/workitems/$"+ $workitemType + "?api-version=6.0"
                    $body = @"
                    [
                    {
                        "op" : "add",
                        "path" : "/fields/System.Title",
                        "value" : " $($RunID)- (Run ID) $($currentTestCase.testCaseTitle)"
                    },
                    {
                        "op" : "add",
                        "path" : "/fields/System.Reason",
                        "value" : "Build Failure"
                    },
                    {
                        "op" : "add",
                        "path" : "/fields/System.AreaPath",
                        "value" : "$($Project)\\$($Area)"
                       
                    },
                    {
                        "op": "add",
                        "path": "/fields/System.AssignedTo",
                        "value": "$($AssignedTo)"
                    },
                    {
                        "op": "add",
                        "path": "/fields/System.Description",
                        "value": "$($currentTestCase.testCaseTitle)"
                    },
                    {
                        "op": "add",
                        "path": "/fields/Microsoft.VSTS.TCM.SystemInfo",
                        "value": "Test case ID $($RunID)"
                    },
                    {
                        "op": "add",
                        "path": "/fields/System.Tags",
                        "value": "$($tags)"
                    }
                ] "@
              try{
                $BugItemresults = Invoke-RestMethod $createBugWorkItemUrl -Method POST -ContentType "application/json-patch+json" -Headers $header -Body $body
                }
              catch {
                     write-host "failed while creating a bug from url  $BugItemresults !" -ForegroundColor Red
                     write-host $_.Exception.Message -ForegroundColor Red
                    } 
               Write-Host "Bug created for failed test case" $BugItemresults.id -ForegroundColor Red
            }
            }
             
         }
    }
}
end {
    Write-host "***** Write-Host "Bug created for failed test case" -ForegroundColor Red*****"
}