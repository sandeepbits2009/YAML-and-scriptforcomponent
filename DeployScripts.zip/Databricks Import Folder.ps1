<#
.SYNOPSIS
Imports folder to the Databricks workspace.
  
.PARAMETER BearerToken
Your Databricks Bearer token to authenticate to your workspace (see User Settings in Databricks WebUI)
 
.PARAMETER Region
Azure Region - must match the URL of your Databricks workspace, example northeurope
 
.PARAMETER LocalPath
Localpath in which all the files are existing to get imported to the Databricks path

.PARAMETER DataBricksPath
Databricks path in the workspace to which the files needs to be imported

.EXAMPLE
C:\PS> 	Databricks Import Folder.ps1 -BearerToken $BearerToken -Region $Region -LocalPath $LocalPath -DataBricksPath 'Shared'
 
The above example imports the files to the Databricks workspace
#>

[CmdletBinding()]
param(
   
    [Parameter(Mandatory = $true)]$BearerToken, 
    [Parameter(Mandatory = $true)]$Region, 
    [Parameter(Mandatory = $true)]$LocalPath, 
    [Parameter(Mandatory = $true)]$DataBricksPath
	)

begin
{
    write-host `Region         :  $Region
    write-host `LocalPath      :  $LocalPath
    write-host `DataBricksPath :  $DataBricksPath
}

process
{
    Write-host "*****Task Open: Importing the Databricks to the DBS*****"

	Write-Host "*****Task 1: Installing PowerShell Module: azure.databricks.cicd.tools*****"

    if (Get-Module -ListAvailable -Name azure.databricks.cicd.tools) {
    Write-Host "azure.databricks.cicd.tools Module already exists"
    } 
    else {
    Write-Host "Module does not exist, Installing ..."
    Install-Module -Name azure.databricks.cicd.tools -Verbose -Scope CurrentUser -Force
    }   
    
    Write-Host "*****Task 2: Importing PowerShell Module: azure.databricks.cicd.tools*****"
    Import-Module -Name azure.databricks.cicd.tools -Verbose
	
	try {
		 	Write-Host "*****Task 3: Importing DataBricks Folder to the Quality DBFS*****"
            Import-DatabricksFolder -BearerToken $BearerToken -Region $Region -LocalPath $LocalPath -DatabricksPath $DataBricksPath -Verbose
	}
	catch {
		 Write-Host $_.Exception.Message -ForegroundColor Red
	}
}

end
{
    Write-host "*****Task Complete: Imported the Databricks folder to the DBS*****"
}