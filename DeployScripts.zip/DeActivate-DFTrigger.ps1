﻿<#
.SYNOPSIS
Deactivates the Triggers in the DataFactory
 
.PARAMETER ResourceGroupName
Resource group Name in Azure
 
.PARAMETER ApplicationId(Optional)
Application ID of the Application registered in Azure Active Directory
 
.PARAMETER SecurePassword(Optional)
Secure Password string of the Application
     
.PARAMETER TenantId(Optional)
Tenant ID of the Application registered in Azure Active Directory

.PARAMETER DataFactoryName (Optional)
Name of the DataFactory Name

.EXAMPLE
This script Deactivates the trigger in the Azure Data Factory. DataFactory name is optional input . If its not passed , Value will be fetched from the resourcegroup.



Manual Usage - 
If script needs to be triggered manually for testing and other purpose, ApplicationID,TenantID and Securepassword are required for successful manual run

C:\PS> DeActivate-DFTrigger.ps1 -ResourceGroupName $ResourceGroupName -ApplicationId $ApplicationId -SecurePassword $SecurePassword -TenantId $TenantId

CI Usage (Azure Powershell tasks)

If the script is invoked via Azure powershell task  ApplicationID,TenantID and Securepassword are not required since the task itself
integrates with Azure resources using automated service principal.

C:\PS> DeActivate-DFTrigger.ps1 -ResourceGroupName $ResourceGroupName 




#>
[CmdletBinding()]
param(
   
	[Parameter(Mandatory = $true)]$ResourceGroupName, 
	[Parameter(Mandatory = $false)]$ApplicationId, 
	[Parameter(Mandatory = $false)]$SecurePassword, 
	[Parameter(Mandatory = $false)]$TenantId,
								  $DataFactoryName
)

begin {
	write-host `ResourceGroupName :  $ResourceGroupName
}

process {
	Write-host "*****Task Open: Deactivating the Triggers for the Datafactory*****"
	if ((Get-Module -ListAvailable -Name AzureRM.DataFactoryV2) -and (Get-Module -ListAvailable -Name AzureRM.Resources)) {
    Write-Host "AzureRM.DataFactoryV2 and AzureRM.Resources Module already exists"
    } 
    else {
    Write-Host "Module does not exist, Installing ..."
    Install-Module -Name AzureRM.DataFactoryV2 -Verbose -Scope CurrentUser -Force
	Install-Module -Name AzureRM.Resources -Verbose -Scope CurrentUser -Force
    }
	
	if ($env:AGENT_ID)
    {		
		Write-host "Script is getting executed on azure ps task . Hence Login parameters are not required to connect azure resources"
	}
	else
	{
	
		$SecurePassword = $SecurePassword | ConvertTo-SecureString -AsPlainText -Force
		$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ApplicationId, $SecurePassword
		
		try {
			Write-host "*****Connect-AzureRmAccount*****"
			Connect-AzureRmAccount -ServicePrincipal -Credential $credential -TenantId $TenantId
		}
		catch {
			Write-Host $_.Exception.Message -ForegroundColor Red
		}
		
		try {
			Write-Host "*****Login-AzureRmAccount*****"
			Login-AzureRmAccount -ServicePrincipal -Credential $credential -TenantId $tenantId
		}
		catch {
			Write-Host $_.Exception.Message -ForegroundColor Red
		}
	}

	$ResourceGroup = Get-AzureRmResourceGroup -Name $ResourceGroupName
	write-host "Resource Group: " $ResourceGroup
	
	try {
		Write-host "*****Task 1: Getting the Datafactory name from the Resource Group*****"
		if(!$DataFactoryName) {
			$Datafactory = Get-AzureRmDataFactoryV2 -ResourceGroupName $ResourceGroupName
			$DataFactoryName = $DataFactory.DataFactoryName
		}
		Write-Host "DataFactoryName: " $DataFactoryName

		Write-Host "*****Task 2: Getting the Trigger Names and RunTimeState from the Datafactory*****"
		$Triggers = Get-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName | select-object -Property Name, RuntimeState
	
		if (!$Triggers) {
			write-host "No Triggers available or failed to get the Triggers for the $DatafactoryName !" -ForegroundColor Red
			write-host $_.Exception.Message -ForegroundColor Red
			write-host $_.Exception.ItemName -ForegroundColor Red
			Exit 1
		}
	
		Write-host "Total Number of Triggers:" $Triggers.count 

		Write-host "*****Task 3: Stopping the Triggers in the Datafactory*****"

		foreach ($Trigger in $Triggers) {

			$TriggerName = $Trigger.Name
			$TriggerStatus = $Trigger.RuntimeState
			Write-host `Trigger   : $TriggerName, $TriggerStatus
		    $result = Stop-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue
#            $timeout = 120
#            $job = Start-Job { $result = Stop-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue}
#            $done = $job |Wait-Job -TimeOut $timeout
#            if($done){
#                Write-Host "Trigger Deactivated within the timeout period" 
#             }
#            else {
#                 Write-Host "Nothing was returned, Trigger Deactivation timed out"
#                 }		    
            if (($?) -and ($result)) {
            write-host "Successfully stopped the trigger!!"
            }
            Else {
            $status = $null
            Do 
            { 
#                $timeout = 120
#                $job = Start-Job { $result = Stop-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue}
#                $done = $job |Wait-Job -TimeOut $timeout
#                if($done){
#                    Write-Host "Trigger Deactivated within the timeout period" 
#                 }
#                else {
#                     Write-Host "Nothing was returned, Trigger Deactivation timed out"
#                     }	
                $result = Stop-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -name $TriggerName -force -ErrorAction SilentlyContinue	    
                $status = Get-AzureRmDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DatafactoryName -Name $TriggerName -ErrorAction SilentlyContinue
                Write-Host "Trying to Stop the $Trigger, Checking the status .."
                if ($($status.RuntimeState) -eq "Stopped")
                {break;}
          } 
        while ($($status.RuntimeState) -eq "Started")
		
       }
	}

}
	catch {
		write-host "Failed to get the DatafactoryName for the $ResourceGroupName !" -ForegroundColor Red
		write-host $_.Exception.Message -ForegroundColor Red
		write-host $_.Exception.ItemName -ForegroundColor Red
		Exit 1
	}

	if (!($env:AGENT_ID))
	{
		Disconnect-AzureRmAccount
		Write-Host "Disconnected from the active azure connection succesfully"
	}
}

end {
	Write-host "*****Task Complete: Activated the Triggers for the Datafactory*****"
}