<#
    .SYNOPSIS
        Copies content from your local machine to a remote Azure Databricks instance.
    .DESCRIPTION
        Copies content from your local machine to a remote Azure Databricks instance. The imported file should be of type ".dbc" (which you can create using the Export-AzureDatabricksContent function).
        Otherwise, it can be a byte array of content. The target directory should not exist, and will be created.
    .PARAMETER LocalPath
        A path to your local DBC file you want to import.
    .PARAMETER BearerToken
        An object that represents an Azure Databricks API BearerToken where you want to copy your content to.
    .PARAMETER DataBricksPath
        The path to copy your content into. The target folder should not exist (but any parent directories should).
    .PARAMETER BaseURI
        Databticks BaseURI
#>
Param (
    [Parameter(Mandatory = $true)]$BearerToken, 
    [Parameter(Mandatory = $true)]$LocalPath, 
    [Parameter(Mandatory = $true)]$DataBricksPath,
    [Parameter(Mandatory = $true)]$BaseURI
)

begin {
    $WriteURI = $BaseURI + "/api/2.0/workspace/import"
    $FilePattern = "*.dbc"
}    

process {

    Function Add-DatabricksFolder {    
        [cmdletbinding()]

        $mkdirsbody = '{"path": "' + $DataBricksPath + '"}'
        $deletebody = '{"path": "' + $DataBricksPath + '", "recursive": true}'
        $Headers = @{
            'Authorization' = "Bearer $BearerToken"
        }

        Try
        {
            Invoke-RestMethod -Method Post -Body $deletebody -Uri "$BaseURI/api/2.0/workspace/delete" -Headers $Headers
            Invoke-RestMethod -Method Post -Body $mkdirsbody -Uri "$BaseURI/api/2.0/workspace/mkdirs" -Headers $Headers
        }
        Catch
        {
            if ($_.ErrorDetails.Message.Contains('already exists') -eq $true)
            {
                Write-Verbose "Folder already exists"
            }
            else
            {
                Write-Error $_.ErrorDetails.Message
                break
            }
        }
    }

    function New-AzureDatabricksRequest {
        Param (
            [Parameter(Mandatory=$true)] [uri] $Uri,
            [Parameter(Mandatory=$true)] [string] $AccessToken,
            [Parameter(Mandatory=$false)] [ValidateSet("GET","POST")] [string] $RequestMethod = "GET",
            [Parameter(Mandatory=$false)] [switch] $ExpectingNoReply,
            [Parameter(Mandatory=$false)] [bool] $UseBasicParsing = $False
        )        

        process {
            $DatabricksRequestObject = New-Object DatabricksRequestObject
            $DatabricksRequestObject.RequestURI = $Uri
            $DatabricksRequestObject.RequestMethod = $RequestMethod
            if ($UseBasicParsing -eq $True) {
                $DatabricksRequestObject.UseBasicParsing = $True
            }
            $DatabricksRequestObject.AddHeader("Authorization","Bearer $AccessToken")
            if ($ExpectingNoReply) {
                $DatabricksRequestObject.IgnoreResponse = $True
            }
            $DatabricksRequestObject
        }
    }

    Write-Host "*****Task 1: Installing PowerShell Module: PSAzureDatabricks*****"

    if (Get-Module -ListAvailable -Name PSAzureDatabricks) {
        Write-Host "PSAzureDatabricks Module already exists"
    }
    else {
        Write-Host "Module does not exist, Installing ..."
        Install-Module -Name PSAzureDatabricks -Verbose -Scope CurrentUser -Force
    }
    
    Write-Host "*****Task 2: Importing PowerShell Module: PSAzureDatabricks*****"
    Import-Module -Name PSAzureDatabricks -Verbose

    try {
        Write-Host "*****Task 3: Importing DataBricks Folder to the Quality DBFS*****"
        Write-Verbose "Getting content we need to deploy..."
        Set-Location $LocalPath
        Add-DatabricksFolder
        $AllFiles = Get-ChildItem -Filter $FilePattern -Recurse -File
        Foreach ($DBCFile in $AllFiles){
            $DBCFile = Resolve-Path $DBCFile.FullName
            $bytes = [IO.File]::ReadAllBytes($DBCFile)
            $importContent = [Convert]::ToBase64String($bytes)
            $Filename = [IO.Path]::GetFileNameWithoutExtension($DBCFile)
            $Path = "$DataBricksPath/$Filename"
            Write-Host "FileTarget: $Path"
            $DeployRequest = New-AzureDatabricksRequest -Uri $WriteURI -AccessToken $BearerToken -RequestMethod POST
            $DeployRequest.AddBody("content",$importContent)
            $DeployRequest.AddBody("path",$Path)
            $DeployRequest.AddBody("format","DBC")
            $DeployResults = $DeployRequest.Submit()
            $DeployResults
        }
    }
	catch {
		 Write-Host $_.Exception.Message -ForegroundColor Red
	}
}
end
{
    Write-host "*****Task Complete: Imported the Databricks dbc files*****"
}