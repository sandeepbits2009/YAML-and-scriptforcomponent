$ProcessActive = Get-Process wlrun -ErrorAction SilentlyContinue
   if($ProcessActive -eq $null)
   {
    Write-host "wlrun is not not running"
    break
   }
   else
   {
    Write-host "wlrun is running"
    Stop-Process -InputObject $ProcessActive
    Write-host "wlrun is killed"
   }