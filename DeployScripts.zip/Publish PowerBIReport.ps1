<#
.SYNOPSIS
Publishes a PowerBI report

.PARAMETER ApplicationId
Application ID of the Application registered in Azure Active Directory
 
.PARAMETER SecurePassword
Secure Password string of the Application
     
.PARAMETER TenantId
Tenant ID of the Application registered in Azure Active Directory

.PARAMETER WorkspaceName
PowerBI Workspace Name
 
.EXAMPLE
C:\PS> Publish PowerBIReport.ps1 -WorkspaceName $WorkspaceName -ApplicationId $ApplicationId -SecurePassword $SecurePassword -TenantId $TenantId
 
This example publishes the report to the PowerBI Workspace
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]$ApplicationId, 
    [Parameter(Mandatory = $true)]$SecurePassword, 
    [Parameter(Mandatory = $true)]$TenantId,
	[Parameter(Mandatory = $true)]$WorkspaceName,
	[Parameter(Mandatory = $true)]$Path
	)

begin
{
    write-host `WorkspaceName :  $WorkspaceName
}

process
{
	Write-host "*****Task Open: Creating a PowerBI reports in the PowerBI Workspace*****"

if ((Get-Module -ListAvailable -Name MicrosoftPowerBIMgmt) -and (Get-Module -ListAvailable -Name MicrosoftPowerBIMgmt.Profile) -and (Get-Module -ListAvailable -Name MicrosoftPowerBIMgmt.workspaces) -and (Get-Module -ListAvailable -Name MicrosoftPowerBIMgmt.reports) -and (Get-Module -ListAvailable -Name MicrosoftPowerBIMgmt.Data)) {
    Write-Host "MicrosoftPowerBIMgmt and its Sub Modules already exists"
    } 
    else {
    Write-Host "Module does not exist, Installing ..."
    Write-host "*****Task 1: Installing Module: MicrosoftPowerBIMgmt *****"
    Install-Module -Name MicrosoftPowerBIMgmt  -Scope CurrentUser -Force
	
	Write-host "*****Task 2: Installing Module: MicrosoftPowerBIMgmt.Profile *****"
	Install-Module -Name MicrosoftPowerBIMgmt.Profile  -Scope CurrentUser -Force
	
	Write-host "*****Task 3: Installing Module: MicrosoftPowerBIMgmt.workspaces *****"
	Install-Module -Name MicrosoftPowerBIMgmt.workspaces  -Scope CurrentUser -Force

	Write-host "*****Task 4: Installing Module: MicrosoftPowerBIMgmt.reports *****"
	Install-Module -Name MicrosoftPowerBIMgmt.reports  -Scope CurrentUser -Force
	
	Write-host "*****Task 5: Installing Module: MicrosoftPowerBIMgmt.Data *****"
	Install-Module -Name MicrosoftPowerBIMgmt.Data  -Scope CurrentUser -Force
    }
	

	$SecurePassword = $SecurePassword | ConvertTo-SecureString -AsPlainText -Force
    $credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ApplicationId, $SecurePassword
	
	$filelist = Get-ChildItem -path $Path -Recurse -Include *.pbix
	
	try {
		Write-host "*****Task 6: Connect-PowerBIServiceAccount*****"
    	Connect-PowerBIServiceAccount -ServicePrincipal -Credential $credential -TenantId $TenantId
		
		Write-host "*****Task 6: Getting the PowerBI Workspace *****"
		$Workspace = Get-PowerBIWorkspace -Name $WorkspaceName
				
		if ($Workspace) {
			    write-host "WorkspaceId: " + $Workspace.id
				
				Write-host "*****Task 7: Creating the PowerBI Reports in the PowerBI Workspace *****"
				Write-host "Reports in the folder: " $filelist.Name
				
				foreach ($files in $filelist) {
					$f = Join-path -Path $Path -ChildPath $files.Name
					write-host "Report to upload: " $f
					New-PowerBIReport -WorkspaceId $Workspace.id -Path $f -ConflictAction CreateOrOverwrite
				}
		    }
		    else {
			    write-host "No Workspace available in $WorkspaceName !" -ForegroundColor Red
			    write-host $_.Exception.Message -ForegroundColor Red
			    write-host $_.Exception.ItemName -ForegroundColor Red
				Exit 1
			}
		}
	catch {
		 Write-Host $_.Exception.Message -ForegroundColor Red
		 Exit 1
	}
    
	Write-Host "*****Task 4: Disconnect-AzureRmAccount*****"
    Disconnect-PowerBIServiceAccount
}

end
{
    Write-host "*****Task Complete:Creating a PowerBI reports in the PowerBI Workspace*****"
}