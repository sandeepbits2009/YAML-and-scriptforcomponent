<#
.Synopsis
Script helps to deploy the  eventhub endpoints and shared access policies for the endpoints . User needs to fill out the JSON file for each environment and the same file
will be considered as input for this script . 

Note- Script dont have authentication mechanism currently to connect with azure services . Please use the script in Azure CLI task in pipeline for automatic authentication

.PARAMETER JsonPath
Input Json file path required for the deployment and its mandatory

.EXAMPLE

./Deploy-EventHub.ps1 -JsonPath C:\temp\Parameter_QA.json

#>
param (
     [Parameter(Mandatory = $true)][String]$JsonPath
)
try
{
    
    $ReadJson =  Get-Content -Path $JsonPath -Raw | ConvertFrom-Json
    foreach ($eventhub in $ReadJson.Eventhub)
    {
       $EventhubName = $eventhub.EventHubname
       $ResourceGroupname = $eventhub.ResourceGroupName
       $Eventhubnamespace =  $eventhub.NameSpacename
       $StorageAccount = $eventhub.StorageAccount
       $ContainerName =  $eventhub.ContainerName
       $Enablecapture = $eventhub.EnableCapture
       $Messageretention = $eventhub.Messageretention
       $PartitionCount = $eventhub.PartitionCount
       $DestinationName = $eventhub.DestinationName
       $SharedPolicyname = $eventhub.SharedPolicyname
       $PolicyRights   = $eventhub.PolicyRights
       
        
        $Arguments = "az eventhubs eventhub create --resource-group {0} --namespace-name {1} --name {2} --message-retention {3} --partition-count {4} --storage-account {5} --blob-container {6} --destination-name {7} --enable-capture {8}"
        $Arguments = ($Arguments -f $Resourcegroupname, $Eventhubnamespace, $Eventhubname , $MessageRetention , $PartitionCount , "$StorageAccount" , $ContainerName , $DestinationName , $Enablecapture )  
        Write-Host Constructed arguements are $Arguments
        Write-host "Deploying $EventhubName started ..."
        Invoke-expression $Arguments
        Write-Host "Succesfully deployed the $EventhubName endpoint" -Foregroundcolor Green

        $AuthorizationruleArguments = "az eventhubs eventhub authorization-rule create --resource-group {0} --namespace-name {1} --eventhub-name {2} --name {3} --rights {4}"
        $AuthorizationruleArguments = ($AuthorizationruleArguments -f $ResourceGroupname, $Eventhubnamespace, $Eventhubname, $SharedPolicyname, $PolicyRights)
        Write-Host "Creating authorizationrule for eventhub $EventhubName started"
        Invoke-expression $AuthorizationruleArguments
        Write-Host "Enabled the authorizationrule $SharedPolicyname to the eventhub $EventhubName" -Foregroundcolor Green
    }
}
catch
{
    Write-host "Failed to create the eventhub endpoint & authorization .Please refer the below error message" -Foregroundcolor Red
    Write-host "Failure reason : $_ " -Foregroundcolor Red
    exit 1
}