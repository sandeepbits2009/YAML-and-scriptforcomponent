﻿<#
.SYNOPSIS
Invoke the pipeline in the DataFactory and Waits until the Pipeline run is completed
 
.PARAMETER ResourceGroupName
Resource group Name in Azure
 
.PARAMETER pipelineName
Name of the Pipeline in the Azure Data Factory
     
.PARAMETER pollFrequency
Frequency in which Polling needs to be performed
 
.EXAMPLE
This script Invoke the pipeline in the DataFactory, gets the Status of the Pipelun Run and waits until it is completed

C:\PS> Invoke-ADFPipeline.ps1 -ResourceGroupName $ResourceGroupName -pipelineName $pipelineName -pollFrequency $pollFrequency
#>

[CmdletBinding()]

param(
    [Parameter(Mandatory = $true)]$ResourceGroupName, 
    [Parameter(Mandatory = $true)]$pipelineName, 
    [Parameter(Mandatory = $true)]$pollFrequency
  	)

begin
{
    write-host `ResourceGroupName :  $ResourceGroupName
    write-host `pipelineName      :  $pipelineName
}

process
{
    Write-host "*****Task Open: Activating the Triggers for the Datafactory*****"
	try
	{
		az config set extension.use_dynamic_install=yes_without_prompt
			Write-host "*****Task 1: Getting the Datafactory name from the Resource Group*****"
			$datafactoryList = az datafactory list --resource-group $ResourceGroupName | ConvertFrom-Json
			$Datafactoryname = $datafactoryList.name
			Write-Host "DataFactoryName: " $DatafactoryName


       		$executionId = az datafactory pipeline create-run --factory-name $Datafactoryname --name $pipelineName --resource-group $ResourceGroupName | ConvertFrom-Json
			$executionId = $executionId.runId
			$runStatus = az datafactory pipeline-run show --factory-name $Datafactoryname --resource-group $ResourceGroupName --run-id $executionId | ConvertFrom-Json
			$runStatus = $runStatus.status
			
        	While (($runStatus -eq 'InProgress') -or ($runStatus -eq 'Queued')) 
			{
        	Write-Host ("Pipeline {0} in progress" -f $pipelineName)
        	 Start-Sleep $pollFrequency
			
			$runStatus = az datafactory pipeline-run show --factory-name $Datafactoryname --resource-group $ResourceGroupName --run-id $executionId | ConvertFrom-Json
			$runStatus = $runStatus.status
			}
		Write-Host ("Pipeline {0} finished with status {1}" -f $pipelineName, $runStatus)
	}
	catch
	{
		write-host "Failed to get the DatafactoryName for the $ResourceGroupName !" -ForegroundColor Red
        write-host $_.Exception.Message -ForegroundColor Red
        write-host $_.Exception.ItemName -ForegroundColor Red
		Exit 1
		
	}	    
}

end
{
    Write-host "*****Task Complete: Activated the Triggers for the Datafactory*****"
}