from django.apps import AppConfig


class OktaOauth2Config(AppConfig):
    name = "okta_oauth2"
