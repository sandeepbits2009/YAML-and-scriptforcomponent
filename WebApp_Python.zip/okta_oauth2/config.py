import os

# OKTA CONFIG
OKTA_CLIENT_ID = os.environ.get("OKTA_CLIENT_ID", None)
OKTA_ORG_URL = os.environ.get("OKTA_ORG_URL", None)
OKTA_REDIRECT_URL = os.environ.get("OKTA_REDIRECT_URL", None)
OKTA_SCOPES = "openid profile email"
OKTA_ISSUER = os.environ.get("OKTA_ISSUER", None)
OKTA_CLIENT_SECRET = os.environ.get("OKTA_CLIENT_SECRET", None)
