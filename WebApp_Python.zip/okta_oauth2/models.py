from __future__ import unicode_literals
import requests
import okta_oauth2.config as config


class OktaConfig:
    # Configuration object
    org_url = config.OKTA_ORG_URL

    # OpenID Specific
    grant_type = "authorization_code"
    client_id = config.OKTA_CLIENT_ID
    client_secret = config.OKTA_CLIENT_SECRET
    issuer = config.OKTA_ISSUER
    scopes = config.OKTA_SCOPES
    redirect_uri = config.OKTA_REDIRECT_URL


class DiscoveryDocument:
    # Find the OIDC metadata through discovery
    def __init__(self, issuer_uri):
        r = requests.get(issuer_uri + "/.well-known/openid-configuration")
        self.json = r.json()

    def getJson(self):
        return self.json


class TokenManager:
    def __init__(self):
        self.idToken = None
        self.accessToken = None
        self.claims = None

    def set_id_token(self, token):
        self.idToken = token

    def set_access_token(self, token):
        self.accessToken = token

    def set_claims(self, claims):
        self.claims = claims

    def getJson(self):
        response = {}
        if self.idToken:
            response["idToken"] = self.idToken

        if self.accessToken:
            response["accessToken"] = self.accessToken

        if self.claims:
            response["claims"] = self.claims
        return response
